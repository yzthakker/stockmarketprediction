#### Predict For RELCAP USING VARIOUS CLASSIFIERS ####

from datafetch import *
import numpy

#print(len(relcapital))
bon=len(relcapital)*95/100
bon=round(bon)

relcapital=relcapital['Return'].values
cnx=cnx_nifty['Return'].values
bse=bse['Return'].values
hang_seng=hang_seng['Return'].values
ftse=ftse['Return'].values
axjo=axjo['Return'].values


'''
labels_train=tata_profit[:bon]

fetures_test=tata[bon:]['AdjClose'].values
labels_test=tata_profit[bon:]
'''

data=[]
for i in range(0,len(relcapital)):
    if i>=15 :
        l=relcapital[i-15:i].tolist()
        l.append(cnx[i-1])
        l.append(bse[i-1])
        l.append(hang_seng[i-1])
        l.append(ftse[i-1])
        l.append(axjo[i-1])    
        #print(l)
        data.append(l)
    else:
        data.append([0])

#print(len(data))
#print(bon)
features_train=data[15:bon]
labels_train=relcapital_profit[15:bon]
features_test=data[bon:]
labels_test=relcapital_profit[bon:]

#print(len(features_train),len(features_test),len(labels_train),len(labels_test))
X=numpy.array(features_train)
Y=numpy.array(labels_train)

print("RELCAPITAL")
##########################################
from sklearn.naive_bayes import GaussianNB
clf = GaussianNB()
clf.fit(X,Y)
ans=clf.predict(numpy.array(features_test))
#print(ans)
print("NB : ",clf.score(features_test,labels_test))
##########################################
from sklearn import svm
clf=svm.SVC()
clf.fit(X,Y)
ans=clf.predict(numpy.array(features_test))
#print(ans)
print("SVM : ",clf.score(features_test,labels_test))
##########################################
from sklearn import tree
clf=tree.DecisionTreeClassifier()
clf.fit(X,Y)
ans=clf.predict(numpy.array(features_test))
#print(ans)
print("Decision tree : ",clf.score(features_test,labels_test))
##########################################
from sklearn.neighbors import KNeighborsClassifier
clf=KNeighborsClassifier(n_neighbors=100)
clf.fit(X,Y)
ans=clf.predict(numpy.array(features_test))
#print(ans)
print("K Nearest Neighbor : ",clf.score(features_test,labels_test))
##########################################
from sklearn.ensemble import RandomForestClassifier
clf=RandomForestClassifier(n_estimators=16)
clf.fit(X,Y)
ans=clf.predict(numpy.array(features_test))
#print(ans)
print("RandomForest : ",clf.score(features_test,labels_test))
##########################################
from sklearn.ensemble import AdaBoostClassifier
clf = AdaBoostClassifier(n_estimators=100)
clf.fit(X,Y)
ans=clf.predict(numpy.array(features_test))
print("AdaBoost : ",clf.score(features_test,labels_test))
