#### Featches data from downloaded CSV FIle And Save it into Data Frame ####
#### Also calculates % return on Adj_Close and profit ( up (1) and down(-1) of the day) ####

import csv
import numpy
import pandas
from datetime import date

base_date=date(2009,1,1)
end_date=date(2014,12,31)

#TATASTEEL6.BO
tata=pandas.DataFrame.from_csv('tata.csv')
tata=tata.rename(columns= {'Adj Close':'AdjClose'})
tata=tata.resample('D',how='mean')
tata=tata.fillna(method='pad')
tata['Return'] = tata['AdjClose'].pct_change(periods=1)
tata['Volume_change']=tata['Volume'].pct_change(periods=1)
tata=tata.ix[2:]
#print(tata)


#RELCAPITAL.BO
relcapital=pandas.DataFrame.from_csv('relcapital.csv')
relcapital=relcapital.rename(columns= {'Adj Close':'AdjClose'})
relcapital=relcapital.resample('D',how='mean')
relcapital=relcapital.fillna(method='pad')
relcapital['Return'] = relcapital['AdjClose'].pct_change(periods=1)
relcapital=relcapital.ix[2:]
#print(relcapital)


#LICHSFIN.NS
lichfl=pandas.DataFrame.from_csv('lichfl.csv')
lichfl=lichfl.rename(columns= {'Adj Close':'AdjClose'})
lichfl=lichfl.resample('D',how='mean')
lichfl=lichfl.fillna(method='pad')
lichfl['Return'] = lichfl['AdjClose'].pct_change(periods=1)
lichfl=lichfl.ix[2:]
#print(relcapital)


#^IXIC
nasdaq=pandas.DataFrame.from_csv('nasdaq.csv')
nasdaq=nasdaq.rename(columns= {'Adj Close':'AdjClose'})
nasdaq=nasdaq.resample('D',how='mean')
nasdaq=nasdaq.fillna(method='pad')
nasdaq['Return'] = nasdaq['AdjClose'].pct_change(periods=1)
nasdaq=nasdaq.ix[1:]
#print(nasdaq)        



#^HSI
hang_seng=pandas.DataFrame.from_csv('hang_seng.csv')
hang_seng=hang_seng.rename(columns= {'Adj Close':'AdjClose'})
hang_seng=hang_seng.resample('D',how='mean')
hang_seng=hang_seng.fillna(method='pad')
hang_seng['Return'] = hang_seng['AdjClose'].pct_change(periods=1)
hang_seng=hang_seng.ix[1:]
#print(hang_seng)        




#^GDAXI
gdaxi=pandas.DataFrame.from_csv('gdaxi.csv')
gdaxi=gdaxi.rename(columns= {'Adj Close':'AdjClose'})
gdaxi=gdaxi.resample('D',how='mean')
gdaxi=gdaxi.fillna(method='pad')
gdaxi['Return'] = gdaxi['AdjClose'].pct_change(periods=1)
gdaxi=gdaxi.ix[:]
#print(nasdaq)        




#^FTSE
ftse=pandas.DataFrame.from_csv('ftse.csv')
ftse=ftse.rename(columns= {'Adj Close':'AdjClose'})
ftse=ftse.resample('D',how='mean')
ftse=ftse.fillna(method='pad')
ftse['Return'] = ftse['AdjClose'].pct_change(periods=1)
ftse=ftse.ix[2:]
#print(nasdaq)        




#^AXJO
axjo=pandas.DataFrame.from_csv('axjo.csv')
axjo=axjo.rename(columns= {'Adj Close':'AdjClose'})
axjo=axjo.resample('D',how='mean')
axjo=axjo.fillna(method='pad')
axjo['Return'] = axjo['AdjClose'].pct_change(periods=1)
axjo=axjo.ix[1:]
#print(nasdaq)



#^BSESN
bse=pandas.DataFrame.from_csv('bse.csv')
bse=bse.rename(columns= {'Adj Close':'AdjClose'})
bse=bse.resample('D',how='mean')
bse=bse.fillna(method='pad')
bse['Return'] = bse['AdjClose'].pct_change(periods=1)
bse=bse.ix[1:]
#print(bse)


#^NSEI
cnx_nifty=pandas.DataFrame.from_csv('cnx_nifty.csv')
cnx_nifty=cnx_nifty.rename(columns= {'Adj Close':'AdjClose'})
cnx_nifty=cnx_nifty.resample('D',how='mean')
cnx_nifty=cnx_nifty.fillna(method='pad')
cnx_nifty['Return'] = cnx_nifty['AdjClose'].pct_change(periods=1)
cnx_nifty=cnx_nifty.ix[2:]
#print(cnx_nifty)        


#Market Vectors INR/USD ETN
inr=pandas.DataFrame.from_csv('inr.csv')
inr=inr.rename(columns= {'Adj Close':'AdjClose'})
inr=inr.resample('D',how='mean')
inr=inr.fillna(method='pad')
inr['Return'] = inr['AdjClose'].pct_change(periods=1)
inr=inr.ix[1:]
#print(cnx_nifty)        


#MCX.NS
mcx=pandas.DataFrame.from_csv('mcx.csv')
mcx=mcx.rename(columns= {'Adj Close':'AdjClose'})
mcx=mcx.resample('D',how='mean')
mcx=mcx.fillna(method='pad')
mcx['Return'] = mcx['AdjClose'].pct_change(periods=1)
mcx=mcx.ix[1:]
mcx_date=date(2012,3,9)
#print(mcx)

#################################################################################################################################
tata_profit=numpy.where(tata['Return']>0,1,-1)
relcapital_profit=numpy.where(relcapital['Return']>0,1,-1)
lichfl_profit=numpy.where(lichfl['Return']>0,1,-1)

volume_change_tata=numpy.where(tata['Volume_change']>0,1,-1)


cnx_profit=numpy.where(cnx_nifty['Return']>0,1,-1)
bse_profit=numpy.where(bse['Return']>0,1,-1)
nasdaq_profit=numpy.where(nasdaq['Return']>0,1,-1)
hang_profit=numpy.where(hang_seng['Return']>0,1,-1)
gdaxi_profit=numpy.where(gdaxi['Return']>0,1,-1)
ftse_profit=numpy.where(ftse['Return']>0,1,-1)
axjo_profit=numpy.where(axjo['Return']>0,1,-1)

inr_profit=numpy.where(inr['Return']>0,1,-1)
mcx_profit=numpy.where(mcx['Return']>0,1,-1)


'''
print("Corelations : ")
print("Tata and CNX_Nifty : ",numpy.correlate(cnx_profit,tata_profit,"value")/len(cnx_profit))
print("Tata and BSE : ",numpy.correlate(bse_profit,tata_profit,"value")/len(bse_profit))
print("Tata and NASDAQ : ",numpy.correlate(nasdaq_profit,tata_profit,"value")/len(nasdaq_profit))
print("Tata and Hang_Seng : ",numpy.correlate(hang_profit,tata_profit,"value")/len(hang_profit))
print("Tata and GDAXI : ",numpy.correlate(gdaxi_profit,tata_profit,"value")/len(gdaxi))
print("Tata and FTSE : ",numpy.correlate(ftse_profit,tata_profit,"value")/len(ftse))
print("Tata and AXJO : ",numpy.correlate(axjo_profit,tata_profit,"value")/len(axjo))

#################################################################################################################################
print()
print()




print("Corelations : ")
print("RelCapital and CNX_Nifty : ",numpy.correlate(cnx_profit,relcapital_profit,"value")/len(cnx_profit))
print("RelCapital and BSE : ",numpy.correlate(bse_profit,relcapital_profit,"value")/len(bse_profit))
print("RelCapital and NASDAQ : ",numpy.correlate(nasdaq_profit,relcapital_profit,"value")/len(nasdaq_profit))
print("RelCapital and Hang_Seng : ",numpy.correlate(hang_profit,relcapital_profit,"value")/len(hang_profit))
print("RelCapital and GDAXI : ",numpy.correlate(gdaxi_profit,relcapital_profit,"value")/len(gdaxi))
print("RelCapital and FTSE : ",numpy.correlate(ftse_profit,relcapital_profit,"value")/len(ftse))
print("RelCapital and AXJO : ",numpy.correlate(axjo_profit,relcapital_profit,"value")/len(axjo))


#################################################################################################################################
print()
print()





print("Corelations : ")
print("LICHFL and CNX_Nifty : ",numpy.correlate(cnx_profit,lichfl_profit,"value")/len(cnx_profit))
print("LICHFL and BSE : ",numpy.correlate(bse_profit,lichfl_profit,"value")/len(bse_profit))
print("LICHFL and NASDAQ : ",numpy.correlate(nasdaq_profit,lichfl_profit,"value")/len(nasdaq_profit))
print("LICHFL and Hang_Seng : ",numpy.correlate(hang_profit,lichfl_profit,"value")/len(hang_profit))
print("LICHFL and GDAXI : ",numpy.correlate(gdaxi_profit,lichfl_profit,"value")/len(gdaxi))
print("LICHFL and FTSE : ",numpy.correlate(ftse_profit,lichfl_profit,"value")/len(ftse))
print("LICHFL and AXJO : ",numpy.correlate(axjo_profit,lichfl_profit,"value")/len(axjo))




#################################################################################################################################
print()
print()

print("Corelations : ")
print("BSE and CNX_Nifty : ",numpy.correlate(cnx_profit,bse_profit,"value")/len(cnx_profit))
print("BSE and NASDAQ : ",numpy.correlate(nasdaq_profit,bse_profit,"value")/len(nasdaq_profit))
print("BSE and Hang_Seng : ",numpy.correlate(hang_profit,bse_profit,"value")/len(hang_profit))
print("BSE and GDAXI : ",numpy.correlate(gdaxi_profit,bse_profit,"value")/len(gdaxi))
print("BSE and FTSE : ",numpy.correlate(ftse_profit,bse_profit,"value")/len(ftse))
print("BSE and AXJO : ",numpy.correlate(axjo_profit,bse_profit,"value")/len(axjo))

'''
